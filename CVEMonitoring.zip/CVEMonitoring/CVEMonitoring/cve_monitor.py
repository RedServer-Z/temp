#!/usr/bin/env python3
"""
CVE Monitoring Script
Monitors CVEs for specified products from current and previous day using NVD API
"""

import requests
import json
from datetime import datetime, timedelta
from typing import List, Dict
import time

# List of products to monitor
PRODUCTS = [
    "sap", "hana", "mongodb", "netweaver", "successfactors", "apache", "httpd", 
    "nginx", "java", "linux", "exim", "smtpd", "node", "squid", "react", "http", 
    "ftp", "tcp", "icmp", "rdp", "ssh", "telnet", "smtp", "dns", "tftp", "dhcp", 
    "tls", "arp", "bgp", "smb", "igmp", "rpc", "onedrive", "teams", "edge", 
    "word", "excel", "office", "powershell", "powerpoint", "chrome", "7zip", 
    "moveit", "adobe", "jdk", "jre", "guacamole", "splunk", "suricata", "checkmk", 
    "microsoft", "copilot", "perplexity", "chatgpt", "kubernetes", "cisco", "terraform"
]

class CVEMonitor:
    def __init__(self, api_key=None):
        self.base_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
        self.headers = {
            'User-Agent': 'CVE-Monitor-Script/1.0'
        }
        
        # Add API key if provided
        if api_key:
            self.headers['apiKey'] = api_key
            print(f"✓ Using NVD API key (rate limit: 50 requests per 30 seconds)")
        else:
            print(f"⚠ Warning: No API key provided (rate limit: 5 requests per 30 seconds)")
            print(f"  Get a free API key at: https://nvd.nist.gov/developers/request-an-api-key\n")
        
    def get_date_range(self, days_ago: int = 0) -> tuple:
        """Get start and end datetime for a specific day"""
        target_date = datetime.now() - timedelta(days=days_ago)
        start = target_date.replace(hour=0, minute=0, second=0, microsecond=0)
        end = target_date.replace(hour=23, minute=59, second=59, microsecond=999999)
        return start, end
    
    def format_datetime_nvd(self, dt: datetime) -> str:
        """Format datetime for NVD API (ISO 8601 format)"""
        return dt.strftime('%Y-%m-%dT%H:%M:%S.000')
    
    def search_cves(self, keyword: str, start_date: datetime, end_date: datetime) -> List[Dict]:
        """Search for CVEs containing a keyword within a date range"""
        params = {
            'keywordSearch': keyword,
            'pubStartDate': self.format_datetime_nvd(start_date),
            'pubEndDate': self.format_datetime_nvd(end_date)
        }
        
        try:
            response = requests.get(self.base_url, params=params, headers=self.headers, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            if 'vulnerabilities' in data:
                return data['vulnerabilities']
            return []
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching CVEs for '{keyword}': {e}")
            return []
        except json.JSONDecodeError:
            print(f"Error parsing response for '{keyword}'")
            return []
    
    def extract_cve_info(self, cve_item: Dict) -> Dict:
        """Extract relevant information from CVE item"""
        cve = cve_item.get('cve', {})
        cve_id = cve.get('id', 'N/A')
        
        # Get description
        descriptions = cve.get('descriptions', [])
        description = next((d['value'] for d in descriptions if d.get('lang') == 'en'), 'N/A')
        
        # Get CVSS scores and detailed metrics
        metrics = cve.get('metrics', {})
        cvss_score = 'N/A'
        severity = 'N/A'
        cvss_vector = 'N/A'
        attack_vector = 'N/A'
        attack_complexity = 'N/A'
        privileges_required = 'N/A'
        user_interaction = 'N/A'
        scope = 'N/A'
        confidentiality = 'N/A'
        integrity = 'N/A'
        availability = 'N/A'
        cvss_version = 'N/A'
        
        if 'cvssMetricV31' in metrics and metrics['cvssMetricV31']:
            metric = metrics['cvssMetricV31'][0]
            cvss_data = metric.get('cvssData', {})
            cvss_score = cvss_data.get('baseScore', 'N/A')
            severity = cvss_data.get('baseSeverity', 'N/A')
            cvss_vector = cvss_data.get('vectorString', 'N/A')
            attack_vector = cvss_data.get('attackVector', 'N/A')
            attack_complexity = cvss_data.get('attackComplexity', 'N/A')
            privileges_required = cvss_data.get('privilegesRequired', 'N/A')
            user_interaction = cvss_data.get('userInteraction', 'N/A')
            scope = cvss_data.get('scope', 'N/A')
            confidentiality = cvss_data.get('confidentialityImpact', 'N/A')
            integrity = cvss_data.get('integrityImpact', 'N/A')
            availability = cvss_data.get('availabilityImpact', 'N/A')
            cvss_version = 'CVSS 3.1'
        elif 'cvssMetricV30' in metrics and metrics['cvssMetricV30']:
            metric = metrics['cvssMetricV30'][0]
            cvss_data = metric.get('cvssData', {})
            cvss_score = cvss_data.get('baseScore', 'N/A')
            severity = cvss_data.get('baseSeverity', 'N/A')
            cvss_vector = cvss_data.get('vectorString', 'N/A')
            attack_vector = cvss_data.get('attackVector', 'N/A')
            attack_complexity = cvss_data.get('attackComplexity', 'N/A')
            privileges_required = cvss_data.get('privilegesRequired', 'N/A')
            user_interaction = cvss_data.get('userInteraction', 'N/A')
            scope = cvss_data.get('scope', 'N/A')
            confidentiality = cvss_data.get('confidentialityImpact', 'N/A')
            integrity = cvss_data.get('integrityImpact', 'N/A')
            availability = cvss_data.get('availabilityImpact', 'N/A')
            cvss_version = 'CVSS 3.0'
        elif 'cvssMetricV2' in metrics and metrics['cvssMetricV2']:
            metric = metrics['cvssMetricV2'][0]
            cvss_data = metric.get('cvssData', {})
            cvss_score = cvss_data.get('baseScore', 'N/A')
            severity = metric.get('baseSeverity', 'N/A')
            cvss_vector = cvss_data.get('vectorString', 'N/A')
            attack_vector = cvss_data.get('accessVector', 'N/A')
            attack_complexity = cvss_data.get('accessComplexity', 'N/A')
            privileges_required = cvss_data.get('authentication', 'N/A')
            confidentiality = cvss_data.get('confidentialityImpact', 'N/A')
            integrity = cvss_data.get('integrityImpact', 'N/A')
            availability = cvss_data.get('availabilityImpact', 'N/A')
            cvss_version = 'CVSS 2.0'
        
        # Get CWE information
        weaknesses = cve.get('weaknesses', [])
        cwe_ids = []
        for weakness in weaknesses:
            for desc in weakness.get('description', []):
                if desc.get('lang') == 'en':
                    cwe_ids.append(desc.get('value', ''))
        cwe_id = ', '.join(cwe_ids) if cwe_ids else 'N/A'
        
        # Get CPE (affected products/versions)
        configurations = cve.get('configurations', [])
        affected_products = []
        for config in configurations:
            for node in config.get('nodes', []):
                for cpe_match in node.get('cpeMatch', []):
                    if cpe_match.get('vulnerable'):
                        cpe_uri = cpe_match.get('criteria', '')
                        if cpe_uri:
                            affected_products.append(cpe_uri)
        
        # Get published date
        published = cve.get('published', 'N/A')
        if published != 'N/A':
            try:
                pub_date = datetime.fromisoformat(published.replace('Z', '+00:00'))
                published = pub_date.strftime('%B %d, %Y')
            except:
                pass
        
        # Get references
        references = cve.get('references', [])
        ref_urls = [ref.get('url', '') for ref in references[:3]]  # Get first 3 references
        
        # Determine authentication requirement
        auth_required = 'Unauthenticated attack'
        if privileges_required not in ['N/A', 'NONE', 'None']:
            auth_required = 'Authenticated attack'
        
        return {
            'id': cve_id,
            'description': description,
            'cvss_score': cvss_score,
            'severity': severity,
            'published': published,
            'cvss_vector': cvss_vector,
            'cvss_version': cvss_version,
            'attack_vector': attack_vector,
            'attack_complexity': attack_complexity,
            'privileges_required': privileges_required,
            'user_interaction': user_interaction,
            'scope': scope,
            'confidentiality': confidentiality,
            'integrity': integrity,
            'availability': availability,
            'cwe_id': cwe_id,
            'affected_products': affected_products,
            'references': ref_urls,
            'auth_required': auth_required
        }
    
    def display_cve_detailed(self, cve: Dict):
        """Display CVE in detailed table format"""
        print(f"\n{cve['id']}")
        print(f"\n{'Field':<35} {'Details'}")
        print("─" * 100)
        print(f"{'CVE ID':<35} {cve['id']}")
        print(f"{'Published Date':<35} {cve['published']}")
        print(f"{'Authenticated / Unauthenticated':<35} {cve['auth_required']}")
        print(f"{'CVSS Score':<35} {cve['cvss_score']} ({cve['severity']}) ({cve['cvss_version']})")
        print(f"{'CVSS Vector':<35} {cve['cvss_vector']}")
        
        # Display affected products
        if cve['affected_products']:
            print(f"{'Affected Application':<35} {cve['affected_products'][0]}")
            for prod in cve['affected_products'][1:3]:  # Show up to 3 products
                print(f"{'':<35} {prod}")
            if len(cve['affected_products']) > 3:
                print(f"{'':<35} ... and {len(cve['affected_products']) - 3} more")
        else:
            print(f"{'Affected Application':<35} Not specified in CVE data")
        
        print(f"{'Attack Vector':<35} {cve['attack_vector']}")
        print(f"{'Exploitation Complexity':<35} {cve['attack_complexity']}")
        print(f"{'Privileges Required':<35} {cve['privileges_required']}")
        print(f"{'User Interaction':<35} {cve['user_interaction']}")
        print(f"{'Scope':<35} {cve['scope']}")
        print(f"{'Impact':<35} Confidentiality: {cve['confidentiality']}, Integrity: {cve['integrity']}, Availability: {cve['availability']}")
        print(f"{'CWE ID':<35} {cve['cwe_id']}")
        print(f"{'Description':<35} {cve['description']}")
        
        # Display references
        if cve['references']:
            print(f"{'References':<35} {cve['references'][0]}")
            for ref in cve['references'][1:]:
                print(f"{'':<35} {ref}")
        
        print("\n" + "=" * 100)
    
    def monitor_products(self, products: List[str], days_ago: int = 0):
        """Monitor CVEs for all products for a specific day"""
        start_date, end_date = self.get_date_range(days_ago)
        day_label = "Today" if days_ago == 0 else f"{days_ago} day(s) ago"
        date_str = start_date.strftime('%Y-%m-%d')
        
        print(f"\n{'='*100}")
        print(f"CVE Report for {day_label} ({date_str})")
        print(f"{'='*100}\n")
        
        total_cves = 0
        product_results = {}
        
        for product in products:
            print(f"Searching for '{product}'...", end=' ')
            cves = self.search_cves(product, start_date, end_date)
            
            if cves:
                product_results[product] = [self.extract_cve_info(cve) for cve in cves]
                print(f"✓ Found {len(cves)} CVE(s)")
                total_cves += len(cves)
            else:
                print("✗ No CVEs found")
            
            # Rate limiting - adjust based on API key availability
            # With API key: 50 requests per 30 seconds = 0.6 seconds between requests
            # Without API key: 5 requests per 30 seconds = 6 seconds between requests
            if 'apiKey' in self.headers:
                time.sleep(0.7)  # Slightly over 0.6 to be safe
            else:
                time.sleep(6.5)  # Slightly over 6 to be safe
        
        # Display results
        print(f"\n{'='*100}")
        print(f"SUMMARY: Total CVEs found: {total_cves}")
        print(f"{'='*100}\n")
        
        if product_results:
            for product, cves in product_results.items():
                print(f"\n{'─'*100}")
                print(f"Product: {product.upper()} ({len(cves)} CVE(s))")
                print(f"{'─'*100}")
                
                for cve in cves:
                    self.display_cve_detailed(cve)
        else:
            print("No CVEs found for any monitored products on this day.")
        
        return total_cves

def main():
    print("="*100)
    print("CVE MONITORING SYSTEM")
    print("="*100)
    print(f"Monitoring {len(PRODUCTS)} products")
    print(f"Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*100)
    
    # =========================================================================
    # INSERT YOUR NVD API KEY HERE
    # Get your free API key at: https://nvd.nist.gov/developers/request-an-api-key
    # =========================================================================
    API_KEY = "None"  # Replace None with "your-api-key-here"
    
    monitor = CVEMonitor(api_key=API_KEY)
    
    # Monitor today's CVEs
    today_count = monitor.monitor_products(PRODUCTS, days_ago=0)
    
    # Monitor yesterday's CVEs
    yesterday_count = monitor.monitor_products(PRODUCTS, days_ago=1)
    
    # Final summary
    print(f"\n{'='*100}")
    print("FINAL SUMMARY")
    print(f"{'='*100}")
    print(f"Today's CVEs: {today_count}")
    print(f"Yesterday's CVEs: {yesterday_count}")
    print(f"Total monitored products: {len(PRODUCTS)}")
    print(f"{'='*100}\n")

if __name__ == "__main__":
    main()
