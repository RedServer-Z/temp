# CVE Monitoring Script

A Python script to monitor CVEs for specified products using the NVD (National Vulnerability Database) API.

## Features

- Monitors 60+ products/technologies for CVEs
- Shows CVEs from both current day and previous day
- Displays CVSS scores and severity levels
- Rate-limited API calls to respect NVD API guidelines
- Clean, formatted output

## Products Monitored

SAP, HANA, MongoDB, NetWeaver, SuccessFactors, Apache, httpd, Nginx, Java, Linux, Exim, SMTPD, Node, Squid, React, HTTP, FTP, TCP, ICMP, RDP, SSH, Telnet, SMTP, DNS, TFTP, DHCP, TLS, ARP, BGP, SMB, IGMP, RPC, OneDrive, Teams, Edge, Word, Excel, Office, PowerShell, PowerPoint, Chrome, 7zip, MoveIt, Adobe, JDK, JRE, Guacamole, Splunk, Suricata, CheckMK, Microsoft, Copilot, Perplexity, ChatGPT, Kubernetes, Cisco, Terraform

## Installation

1. Install Python 3.7 or higher
2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

Run the script:
```bash
python3 cve_monitor.py
```

The script will:
1. Search for CVEs published today for all monitored products
2. Search for CVEs published yesterday for all monitored products
3. Display detailed information including CVE ID, severity, CVSS score, and description
4. Provide a summary of total CVEs found

## Output Format

For each CVE found, the script displays:
- CVE ID
- Severity level (LOW, MEDIUM, HIGH, CRITICAL)
- CVSS score
- Publication date
- Description (truncated to 200 characters)

## API Rate Limiting

The script includes a 1-second delay between API calls to respect NVD API rate limits. For large-scale monitoring, consider:
- Requesting an API key from NVD
- Running the script during off-peak hours
- Adjusting the delay as needed

## Notes

- The script uses NVD API 2.0
- Results depend on how CVEs are tagged in the NVD database
- Some products may return more results than others based on keyword matching
- Network connectivity required

## Customization

To modify the products list, edit the `PRODUCTS` array in the script:
```python
PRODUCTS = [
    "your-product-1",
    "your-product-2",
    # ... add more
]
```

## Troubleshooting

- **No results found**: CVEs may not exist for that day, or the product name may not match NVD records
- **API errors**: Check your internet connection and ensure NVD API is accessible
- **Rate limiting**: If you see many errors, increase the sleep time between requests
